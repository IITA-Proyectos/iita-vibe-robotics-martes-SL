from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port
from pybricks.tools import wait

hub = PrimeHub()

motor_izq = Motor(Port.A)
motor_der = Motor(Port.B)

sensor_izq = ColorSensor(Port.C)
sensor_der = ColorSensor(Port.D)

# 🔥 Velocidades
velocidad_max = 250
velocidad_min = 120

# 🔥 Control PD
Kp = 5
Kd = 2

objetivo = 36
negro = 15
blanco = 60

ultima_direccion = 0
error_anterior = 0

while True:
    luz_izq = sensor_izq.reflection()
    luz_der = sensor_der.reflection()

    print("Izq:", luz_izq, "Der:", luz_der)

    # memoria
    if luz_izq < negro:
        ultima_direccion = -1
    elif luz_der < negro:
        ultima_direccion = 1

    # perdió línea
    if (luz_izq < negro and luz_der < negro) or (luz_izq > blanco and luz_der > blanco):
        
        if ultima_direccion == -1:
            motor_izq.run(-100)
            motor_der.run(200)
        elif ultima_direccion == 1:
            motor_izq.run(-200)
            motor_der.run(100)
        else:
            motor_izq.run(-150)
            motor_der.run(150)

    else:
        # error correcto
        error = (luz_der - objetivo) - (luz_izq - objetivo)
        derivada = error - error_anterior

        correccion = (Kp * error) + (Kd * derivada)
        error_anterior = error

        # 🔥 VELOCIDAD PROGRESIVA (CLAVE)
        magnitud_error = abs(error)

        # cuanto más error → más lento
        velocidad_base = velocidad_max - (magnitud_error * 2)

        # limitar velocidad
        if velocidad_base < velocidad_min:
            velocidad_base = velocidad_min
        if velocidad_base > velocidad_max:
            velocidad_base = velocidad_max

        # limitar corrección
        if correccion > 150:
            correccion = 150
        if correccion < -150:
            correccion = -150

        # motores (izq invertido)
        vel_izq = -velocidad_base + correccion
        vel_der =  velocidad_base + correccion

        # evitar inversión
        if vel_izq > -50:
            vel_izq = -50
        if vel_der < 50:
            vel_der = 50

        motor_izq.run(vel_izq)
        motor_der.run(vel_der)

    wait(10)